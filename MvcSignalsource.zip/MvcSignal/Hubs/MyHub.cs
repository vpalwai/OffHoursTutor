﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using Microsoft.AspNet.SignalR;
using MvcSignal.Models;
using Microsoft.AspNet.SignalR.Hubs;
using System.Configuration;
using System.Xml.Linq;
using System.Xml;
using System.Web.Hosting;
using log4net;

namespace MvcSignal
{
    public class MyHub : Hub
    {
        static List<UserInfo> UsersList = new List<UserInfo>();
        static List<MessageInfo> MessageList = new List<MessageInfo>();
        private static readonly ILog Log = LogManager.GetLogger(System.Reflection.MethodBase.GetCurrentMethod().DeclaringType);

        //-->>>>> ***** Receive Request From Client [  Connect  ] *****
        public void Connect(string userName, string password)
        {
            
                var id = Context.ConnectionId;
                string userGroup = "";
                //Manage Hub Class
                //if freeflag==0 ==> Busy
                //if freeflag==1 ==> Free

                //if tpflag==0 ==> User
                //if tpflag==1 ==> Admin


                //var ctx = new TestEntities1();

                //var userInfo =
                //     (from m in ctx.tbl_User
                //      where m.UserName == userName && m.Password == password
                //      select new { m.UserID, m.UserName, m.AdminCode }).FirstOrDefault();

                //string strFile = Convert.ToString(ConfigurationManager.AppSettings["DataFilePath"]);
                //string strFile = @"~\App_Data\MvcSignalUsers.xml";
                var strFile = System.Web.Hosting.HostingEnvironment.MapPath(@"~/App_Data/MvcSignalUsers.xml");

                XElement xelement = XElement.Load(strFile);

                var userInfo = from m in xelement.Elements("User")
                               where m.Element("UserName").Value.Equals(userName) && m.Element("UserPWD").Value.Equals(password)
                               select m;
                int intAdminCode = 0;
                int intUserID = 0;
                foreach (XElement xFile in userInfo)
                {
                    intUserID = Convert.ToInt32(xFile.Element("UserID").Value);
                    intAdminCode = Convert.ToInt32(xFile.Element("AdminCode").Value);
                }
                if (intUserID == 0)
                {
                    Clients.Caller.NoExistUser();
                }
                

            // Replace (int) userInfo.AdminCode to intAdminCode and userInfo.userID to intUserID

            try
            {
                //You can check if user or admin did not login before by below line which is an if condition
                //if (UsersList.Count(x => x.ConnectionId == id) == 0)

                //Here you check if there is no userGroup which is same DepID --> this is User otherwise this is Admin
                //userGroup = DepID
               
               
                if (intAdminCode == 0)
                {
                    //now we encounter ordinary user which needs userGroup and at this step, system assigns the first of free Admin among UsersList
                    var strg = (from s in UsersList where (s.tpflag == "1") && (s.freeflag == "1") select s).First();
                    userGroup = strg.UserGroup;

                    //Admin becomes busy so we assign zero to freeflag which is shown admin is busy
                    strg.freeflag = "0";

                    //now add USER to UsersList
                    UsersList.Add(new UserInfo { ConnectionId = id, UserID = intUserID, UserName = userName, UserGroup = userGroup, freeflag = "0", tpflag = "0", });
                    //whether it is Admin or User now both of them has userGroup and I Join this user or admin to specific group 
                    Groups.Add(Context.ConnectionId, userGroup);
                    Clients.Caller.onConnected(id, userName, intUserID, userGroup);

                }
                else
                {
                    //If user has admin code so admin code is same userGroup
                    //now add ADMIN to UsersList
                    UsersList.Add(new UserInfo { ConnectionId = id, AdminID = intUserID, UserName = userName, UserGroup = intAdminCode.ToString(), freeflag = "1", tpflag = "1" });
                    //whether it is Admin or User now both of them has userGroup and I Join this user or admin to specific group 
                    Groups.Add(Context.ConnectionId, intAdminCode.ToString());
                    Clients.Caller.onConnected(id, userName, intUserID, intAdminCode.ToString());

                }

            }

            catch
            {
                string msg = "All Administrators are busy, please be patient and try again";
                //***** Return to Client *****
                Clients.Caller.NoExistAdmin();

            }


        }
        // <<<<<-- ***** Return to Client [  NoExist  ] *****



        //--group ***** Receive Request From Client [  SendMessageToGroup  ] *****
        public void SendMessageToGroup(string userName, string message)
        {
            string strUserMsg = "";

            if (UsersList.Count != 0)
            {
                var strg = (from s in UsersList where (s.UserName == userName) select s).First();

                strUserMsg = DateTime.Now.ToString() + "||" + userName + ":\t" + message;

                MessageList.Add(new MessageInfo { UserName = userName, Message = strUserMsg, UserGroup = strg.UserGroup });
                string strgroup = strg.UserGroup;
                // If you want to Broadcast message to all UsersList use below line
                // Clients.All.getMessages(userName, message);

                //If you want to establish peer to peer connection use below line so message will be send just for user and admin who are in same group
                //***** Return to Client *****
                Clients.Group(strgroup).getMessages(userName, message);
            }

        }
        // <<<<<-- ***** Return to Client [  getMessages  ] *****


        //--group ***** Receive Request From Client ***** { Whenever User close session then OnDisconneced will be occurs }
        public override System.Threading.Tasks.Task OnDisconnected()
        {

            var item = UsersList.FirstOrDefault(x => x.ConnectionId == Context.ConnectionId);
            if (item != null)
            {
                UsersList.Remove(item);

                var id = Context.ConnectionId;

                if (item.tpflag == "0")
                {
                    //user logged off == user
                    try
                    {
                        var stradmin = (from s in UsersList where (s.UserGroup == item.UserGroup) && (s.tpflag == "1") select s).First();
                        //become free
                        stradmin.freeflag = "1";
                    }
                    catch
                    {
                        //***** Return to Client *****
                        Clients.Caller.NoExistAdmin();
                    }
                    
                }

                //save conversation to dat abase


            }

            if(MessageList.Count >0)
            {
                var query = from message in MessageList
                            group message.Message by message.UserGroup;

                foreach (var group in query)
                {
                    int i = 0;
                    foreach(var groupmsg in group)
                    {
                        int start, End;
                        if(i ==0 || i == (group.Count() - 1))
                        {
                            Log.Info(groupmsg.ToString());
                        }
                        else
                        {
                            start = groupmsg.IndexOf("||", 0) + 2;
                            End = groupmsg.Length - (groupmsg.IndexOf("||") + 2);
                            Log.Info(groupmsg.ToString().Substring(start, End));
                        }
                        i++;
                    }
                    Log.Info("");
                    Log.Info("*******************************************************************");
                    Log.Info("");
                }
                MessageList.Clear();
            }

            return base.OnDisconnected();
        }
    }
}